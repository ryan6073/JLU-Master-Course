import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split

# 从 Excel 文件中读取数据
data = pd.read_excel('engine_6x.xlsx')

# 分离自变量和因变量
X = data[['Engine_speed', 'Lubricating_oil_pressure', 'Fuel_pressure', 'Coolant_pressure', 'Lubricating_oil_temperature', 'Coolan_temperature']].values  # 六列作为自变量
y = data['engine'].values.reshape(-1, 1)  # 一列作为因变量，并确保形状为 (样本数, 1)

# 将数据划分为训练集和验证集
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# 将数据转换为 PyTorch 张量
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
y_val_tensor = torch.tensor(y_val, dtype=torch.float32)

# 定义三层逻辑回归深度学习模型
class ThreeLayerLogisticRegression(nn.Module):
    def __init__(self):
        super(ThreeLayerLogisticRegression, self).__init__()
        self.fc1 = nn.Linear(6, 100)  # 六个自变量作为输入，映射到100个隐藏单元
        self.fc2 = nn.Linear(100, 50)  # 100个隐藏单元映射到50个隐藏单元
        self.fc3 = nn.Linear(50, 1)  # 50个隐藏单元到输出层

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.sigmoid(self.fc2(x))
        x = torch.sigmoid(self.fc3(x))
        return x

# 创建模型实例
model = ThreeLayerLogisticRegression()

# 定义损失函数和优化器
criterion = nn.BCELoss()  # 二分类问题使用二元交叉熵损失函数
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型
num_epochs = 100
for epoch in range(num_epochs):
    # 前向传播
    outputs = model(X_train_tensor)
    # 计算损失
    loss = criterion(outputs, y_train_tensor)
    # 反向传播及优化
    optimizer.zero_grad()#清除以前的所有梯度
    loss.backward()#反向传播
    optimizer.step()#更新参数

    # 在验证集上计算准确率
    with torch.no_grad():

        val_outputs = model(X_val_tensor)
        val_loss = criterion(val_outputs, y_val_tensor)
        accuracy = ((val_outputs > 0.5) == y_val_tensor).float().mean()

    # 打印损失和准确率
    if (epoch+1) % 10 == 0:
        print(f'Epoch [{epoch+1}/{num_epochs}], Train Loss: {loss.item():.4f}, Val Loss: {val_loss.item():.4f}, Val Accuracy: {accuracy.item():.2f}')