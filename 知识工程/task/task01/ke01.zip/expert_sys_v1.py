import sys
if sys.version_info >= (3, 10):
    from collections.abc import Mapping
    import collections
    collections.Mapping = Mapping
from experta import *

# 定义事实类
class Fact(Fact):
    """基本事实（蓝色节点）"""
    pass

class Intermediate(Fact):
    """中间结论（绿色节点）"""
    pass

class Hypothesis(Fact):
    """最高假设，即动物（黑色节点）"""
    pass

# 定义动物识别引擎
class AnimalIdentifier(KnowledgeEngine):
    # 初始化基本事实（示例，可动态输入）
    @DefFacts()
    def _initial_facts(self):
        # 示例事实：用户输入的动物特征
        yield Fact(name="有毛发")         # F1
        yield Fact(name="吃肉")           # F6
        yield Fact(name="有爪")           # F8
        yield Fact(name="眼睛盯着前方")   # F9
        yield Fact(name="黄褐色")         # F12
        yield Fact(name="有黑色条纹")     # F14

    # 规则 R1
    @Rule(Fact(name="有毛发"))
    def rule1(self):
        self.declare(Intermediate(name="哺乳动物"))  # M1

    # 规则 R2
    @Rule(Fact(name="有奶"))
    def rule2(self):
        self.declare(Intermediate(name="哺乳动物"))  # M1

    # 规则 R3
    @Rule(Fact(name="有羽毛"))
    def rule3(self):
        self.declare(Intermediate(name="鸟"))  # M4

    # 规则 R4
    @Rule(Fact(name="会飞"), Fact(name="下蛋"))
    def rule4(self):
        self.declare(Intermediate(name="鸟"))  # M4

    # 规则 R5
    @Rule(Fact(name="吃肉"))
    def rule5(self):
        self.declare(Intermediate(name="食肉动物"))  # M2

    # 规则 R6
    @Rule(Fact(name="有锋利的牙齿"), Fact(name="有爪"), Fact(name="眼睛盯着前方"))
    def rule6(self):
        self.declare(Intermediate(name="食肉动物"))  # M2

    # 规则 R7
    @Rule(Intermediate(name="哺乳动物"), Fact(name="有蹄"))
    def rule7(self):
        self.declare(Intermediate(name="有蹄类哺乳动物"))  # M3

    # 规则 R8
    @Rule(Intermediate(name="哺乳动物"), Fact(name="反刍"))
    def rule8(self):
        self.declare(Intermediate(name="有蹄类哺乳动物"))  # M3

    # 规则 R9
    @Rule(Intermediate(name="哺乳动物"), Intermediate(name="食肉动物"),
          Fact(name="黄褐色"), Fact(name="有暗斑"))
    def rule9(self):
        self.declare(Hypothesis(name="豹"))  # H1

    # 规则 R10
    @Rule(Intermediate(name="哺乳动物"), Intermediate(name="食肉动物"),
          Fact(name="黄褐色"), Fact(name="有黑色条纹"))
    def rule10(self):
        self.declare(Hypothesis(name="虎"))  # H2

    # 规则 R11
    @Rule(Intermediate(name="有蹄类哺乳动物"), Fact(name="有长脖子"),
          Fact(name="有长腿"), Fact(name="有暗斑"))
    def rule11(self):
        self.declare(Hypothesis(name="长颈鹿"))  # H3

    # 规则 R12
    @Rule(Intermediate(name="有蹄类哺乳动物"), Fact(name="有黑色条纹"))
    def rule12(self):
        self.declare(Hypothesis(name="斑马"))  # H4

    # 规则 R13
    @Rule(Intermediate(name="鸟"), Fact(name="不会飞"), Fact(name="有长脖子"),
          Fact(name="有长腿"), Fact(name="是黑白色"))
    def rule13(self):
        self.declare(Hypothesis(name="鸵鸟"))  # H5

    # 规则 R14
    @Rule(Intermediate(name="鸟"), Fact(name="不会飞"), Fact(name="会游泳"),
          Fact(name="是黑白色"))
    def rule14(self):
        self.declare(Hypothesis(name="企鹅"))  # H6

    # 规则 R15
    @Rule(Intermediate(name="鸟"), Fact(name="善飞"))
    def rule15(self):
        self.declare(Hypothesis(name="信天翁"))  # H7

    # 反向推理：验证特定动物
    def identify_animal(self, animal_name):
        """验证目标动物是否成立"""
        return self.match(Hypothesis(name=animal_name))

    def match(self, goal):
        """检查目标是否在已推导的事实中"""
        return any(fact.get("name") == goal["name"] for fact in self.facts.values()
                   if isinstance(fact, Hypothesis))

# 测试代码
if __name__ == "__main__":
    # 创建并运行引擎
    engine = AnimalIdentifier()
    engine.reset()  # 重置引擎，加载初始事实
    engine.run()    # 执行正向推理

    # 输出正向推理结果
    print("正向推理结果：")
    for fact in engine.facts:
        if isinstance(engine.facts[fact], Hypothesis):
            print(f"识别到动物：{engine.facts[fact]['name']}")

    # 反向推理验证
    animal_to_check = "虎"
    if engine.identify_animal(animal_to_check):
        print(f"反向推理确认：该动物是 {animal_to_check}。")
    else:
        print(f"反向推理未确认：该动物不是 {animal_to_check}。")