def main():
    print("Hello from ke01!")


if __name__ == "__main__":
    main()
