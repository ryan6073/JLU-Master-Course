#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project : ke03
@File : work.py
@Author : Ryan Zhu
@Date : 2025/5/19 18:12
"""

import math


# --- 辅助函数 ---
def prob_to_odds(p):
    """将概率转换为几率 (Odds)"""
    if p == 1.0:
        return float('inf')  # 实际上是无限大几率
    if p == 0.0:
        return 0.0
    if p < 0 or p > 1:
        raise ValueError(f"概率值 {p} 必须在0和1之间。")
    return p / (1 - p)


def odds_to_prob(o):
    """将几率转换为概率"""
    if o == float('inf'):
        return 1.0
    return o / (1 + o)


def calculate_posterior_odds_from_evidences(prior_odds, evidence_params):
    """
    根据先验几率和一系列证据计算后验几率。
    evidence_params: 一个元组列表，每个元组是 (LS, LN, P_evidence)
    """
    current_odds = prior_odds
    for ls, ln, p_evidence in evidence_params:
        if p_evidence < 0 or p_evidence > 1:
            # 允许计算出的中间概率略微超出范围，进行裁剪
            p_evidence = max(0.0, min(1.0, p_evidence))
            # print(f"警告: 证据概率 {p_evidence} 被裁剪至0-1范围。") # 可选的警告

        # 确保 LS 和 LN 是有效的数值
        if not (isinstance(ls, (int, float)) and isinstance(ln, (int, float))):
            raise ValueError(f"LS ({ls}) 或 LN ({ln}) 不是有效的数值。")

        multiplier = (ls * p_evidence) + (ln * (1 - p_evidence))
        current_odds *= multiplier
    return current_odds


# --- 网络参数 ---
# 先验概率 P0(H) - 仅用于被更新的父节点
P0_FRE = 0.001
P0_FLE = 0.005
P0_HYPE = 0.01
P0_SMIR = 0.03
P0_STIR = 0.1
# 注意: P0_RCS, P0_RCAD 等叶节点的先验在此计算中不直接用于更新其父节点，
# 而是使用其作为证据被观察到的概率 P(E_ev)

# 证据规则 (LS, LN)
RULES = {
    "RCS_to_SMIR": {"LS": 300, "LN": 1},
    "RCAD_to_SMIR": {"LS": 75, "LN": 1},
    "RCIB_to_SMIR": {"LS": 20, "LN": 1},
    "RCVP_to_SMIR": {"LS": 4, "LN": 1},
    "SMIRA_to_SMIR": {"LS": 1, "LN": 0.0002},
    "FMGS_PTP_to_STIR": {"LS": 100, "LN": 0.000001},
    "FMGS_to_STIR": {"LS": 2, "LN": 0.000001},  # 新增规则
    "SMIR_to_HYPE": {"LS": 300, "LN": 0.0001},
    "STIR_to_HYPE": {"LS": 65, "LN": 0.01},
    "CVR_to_FLE": {"LS": 800, "LN": 1},  # CVR -> FLE
    "HYPE_to_FLE": {"LS": 200, "LN": 0.0002},
    "FLE_to_FRE": {"LS": 5700, "LN": 0.0001},
    "OTFS_to_FRE": {"LS": 5, "LN": 0.7},
}


# --- 主要计算函数 ---
def calculate_fre_posterior_v2(initial_evidence_probs):
    """
    计算 FRE 节点的后验几率和概率。
    initial_evidence_probs: 包含8个初始证据节点观测概率的字典:
        P_RCS_ev, P_RCAD_ev, P_RCIB_ev, P_RCVP_ev,
        P_FMGS_ev, P_PT_ev, P_OTFS_ev, P_CVR_ev
    """
    P_RCS_ev = initial_evidence_probs["P_RCS_ev"]
    P_RCAD_ev = initial_evidence_probs["P_RCAD_ev"]
    P_RCIB_ev = initial_evidence_probs["P_RCIB_ev"]
    P_RCVP_ev = initial_evidence_probs["P_RCVP_ev"]
    P_FMGS_ev = initial_evidence_probs["P_FMGS_ev"]
    P_PT_ev = initial_evidence_probs["P_PT_ev"]
    P_OTFS_ev = initial_evidence_probs["P_OTFS_ev"]
    P_CVR_ev = initial_evidence_probs["P_CVR_ev"]

    results = {}  # 用于存储所有中间和最终结果

    # 1. 计算 P(SMIRA_calc) - OR 逻辑节点
    # P(SMIRA) = 1 - (1-P(RCS_ev))*(1-P(RCAD_ev))*(1-P(RCIB_ev))*(1-P(RCVP_ev))
    P_SMIRA_calc = 1 - (
            (1 - P_RCS_ev) *
            (1 - P_RCAD_ev) *
            (1 - P_RCIB_ev) *
            (1 - P_RCVP_ev)
    )
    results["P_SMIRA_calc"] = P_SMIRA_calc

    # 2. 计算 P(FMGS_PTP_calc) - AND 逻辑节点
    # P(FMGS&PTP) = P(FMGS_ev) * P(PT_ev)
    P_FMGS_PTP_calc = P_FMGS_ev * P_PT_ev
    results["P_FMGS_PTP_calc"] = P_FMGS_PTP_calc

    # 3. 计算 P(STIR_final)
    O0_STIR = prob_to_odds(P0_STIR)
    O_final_STIR = calculate_posterior_odds_from_evidences(O0_STIR, [
        (RULES["FMGS_PTP_to_STIR"]["LS"], RULES["FMGS_PTP_to_STIR"]["LN"], P_FMGS_PTP_calc),
        (RULES["FMGS_to_STIR"]["LS"], RULES["FMGS_to_STIR"]["LN"], P_FMGS_ev)  # STIR也受FMGS直接影响
    ])
    P_final_STIR = odds_to_prob(O_final_STIR)
    results["P_final_STIR"] = P_final_STIR
    results["O_final_STIR"] = O_final_STIR

    # 4. 计算 P(SMIR_final)
    O0_SMIR = prob_to_odds(P0_SMIR)
    O_final_SMIR = calculate_posterior_odds_from_evidences(O0_SMIR, [
        (RULES["RCS_to_SMIR"]["LS"], RULES["RCS_to_SMIR"]["LN"], P_RCS_ev),
        (RULES["RCAD_to_SMIR"]["LS"], RULES["RCAD_to_SMIR"]["LN"], P_RCAD_ev),
        (RULES["RCIB_to_SMIR"]["LS"], RULES["RCIB_to_SMIR"]["LN"], P_RCIB_ev),
        (RULES["RCVP_to_SMIR"]["LS"], RULES["RCVP_to_SMIR"]["LN"], P_RCVP_ev),
        (RULES["SMIRA_to_SMIR"]["LS"], RULES["SMIRA_to_SMIR"]["LN"], P_SMIRA_calc)
    ])
    P_final_SMIR = odds_to_prob(O_final_SMIR)
    results["P_final_SMIR"] = P_final_SMIR
    results["O_final_SMIR"] = O_final_SMIR

    # 5. 计算 P(HYPE_final)
    O0_HYPE = prob_to_odds(P0_HYPE)
    O_final_HYPE = calculate_posterior_odds_from_evidences(O0_HYPE, [
        (RULES["SMIR_to_HYPE"]["LS"], RULES["SMIR_to_HYPE"]["LN"], P_final_SMIR),
        (RULES["STIR_to_HYPE"]["LS"], RULES["STIR_to_HYPE"]["LN"], P_final_STIR)
    ])
    P_final_HYPE = odds_to_prob(O_final_HYPE)
    results["P_final_HYPE"] = P_final_HYPE
    results["O_final_HYPE"] = O_final_HYPE

    # 6. 计算 P(FLE_final)
    O0_FLE = prob_to_odds(P0_FLE)
    O_final_FLE = calculate_posterior_odds_from_evidences(O0_FLE, [
        (RULES["CVR_to_FLE"]["LS"], RULES["CVR_to_FLE"]["LN"], P_CVR_ev),  # CVR作为证据影响FLE
        (RULES["HYPE_to_FLE"]["LS"], RULES["HYPE_to_FLE"]["LN"], P_final_HYPE)
    ])
    P_final_FLE = odds_to_prob(O_final_FLE)
    results["P_final_FLE"] = P_final_FLE
    results["O_final_FLE"] = O_final_FLE

    # 7. 计算 O_FRE_final 和 P_FRE_final
    O0_FRE = prob_to_odds(P0_FRE)
    O_final_FRE = calculate_posterior_odds_from_evidences(O0_FRE, [
        (RULES["FLE_to_FRE"]["LS"], RULES["FLE_to_FRE"]["LN"], P_final_FLE),
        (RULES["OTFS_to_FRE"]["LS"], RULES["OTFS_to_FRE"]["LN"], P_OTFS_ev)
    ])
    P_final_FRE = odds_to_prob(O_final_FRE)
    results["O_final_FRE"] = O_final_FRE
    results["P_final_FRE"] = P_final_FRE

    return results


# --- 定义两组初始证据概率 ---
# 这些是 P(E_ev)，即证据被观察到的概率
SET1_INITIAL_EVIDENCE_PROBS = {
    "P_RCS_ev": 0.001, "P_RCAD_ev": 0.001, "P_RCIB_ev": 0.001, "P_RCVP_ev": 0.001,
    "P_FMGS_ev": 0.01, "P_PT_ev": 0.01,
    "P_OTFS_ev": 0.1, "P_CVR_ev": 0.001
}

SET2_INITIAL_EVIDENCE_PROBS = {
    "P_RCS_ev": 0.7, "P_RCAD_ev": 0.6, "P_RCIB_ev": 0.5, "P_RCVP_ev": 0.4,
    "P_FMGS_ev": 0.8, "P_PT_ev": 0.8,
    "P_OTFS_ev": 0.75, "P_CVR_ev": 0.2
}

# --- 运行计算 ---
print("情景1 计算 (基准/低概率情景)...")
results_set1 = calculate_fre_posterior_v2(SET1_INITIAL_EVIDENCE_PROBS)
print("\n情景1 结果:")
for key, value in results_set1.items():
    print(f"{key}: {value:.6e}" if isinstance(value, float) else f"{key}: {value}")

print("\n情景2 计算 (高概率/较有利情景)...")
results_set2 = calculate_fre_posterior_v2(SET2_INITIAL_EVIDENCE_PROBS)
print("\n情景2 结果:")
for key, value in results_set2.items():
    print(f"{key}: {value:.6e}" if isinstance(value, float) else f"{key}: {value}")

